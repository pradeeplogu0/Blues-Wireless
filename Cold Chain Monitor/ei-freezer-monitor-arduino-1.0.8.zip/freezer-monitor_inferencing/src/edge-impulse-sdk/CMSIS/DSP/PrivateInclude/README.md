Note: All files have been moved from this folder into Include to simplify build management
